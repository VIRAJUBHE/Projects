package src;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.sql.PreparedStatement;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Scanner;

import java.util.Date;

class AddBooks {
    Scanner sc = new Scanner(System.in);

    public void addBook(String url , String username , String password) throws Exception {

        int ch = 0;
        do {
            System.out.println("*****BOOKING SECTION*****\n");
            System.out.println("1.> ADD BOOK");
            System.out.println("2.> BACK");
            System.out.println();
            ch = sc.nextInt();
            switch (ch) {

                case 1:
                    Identification(url , username , password);
                    break;
                case 2:
                    break;
            }
        } while (ch == 2);

    }

    public void Identification(String url , String username , String password) throws Exception {

        SignIn s = new SignIn();
        Connection con = DriverManager.getConnection(url, username, password);
        String id = " ";
        int count = 0;
        String mail =null;
        while(true){
            System.out.println("Enter your Email for Verification");
            mail = sc.next();
            
            PreparedStatement psp = con.prepareStatement("select count(*) from user where email = ?");
            psp.setString(1, mail);
            ResultSet rsr = psp.executeQuery();
            while(rsr.next()){
                count = rsr.getInt(1);
            }
            if(count > 0){
                System.out.println("\nEMAIL MATCHED\n");
                break;
            }
            else
                System.out.println("\nINVALID EMAIL");
        }


        
        String a = "insert into issue values(?,?,?,?,?)";
        PreparedStatement stmt = con.prepareStatement(a);

        BufferedReader ac = new BufferedReader(new InputStreamReader(System.in));
        String name = " ";

        System.out.println("HOW MANY BOOKS DO YOU WANT TO ADD");
        int counti = sc.nextInt();
        for (int i = 0; i < counti; i++) {
            System.out.println("*****ADD BOOKS TO *****");

            System.out.println("ENTER THE BOOKID OF BOOK YOU WISH TO BORROW");
            id = ac.readLine();

            PreparedStatement ps = con.prepareStatement("select book_name from books where id = ? ;");
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                System.out.println(rs.getString("book_name") + " ");
                name = rs.getString("book_name");
            }

            String cd = new SimpleDateFormat("yyyy.MM.dd").format(new Date());
            System.out.println("Issued Date::" + cd);

            System.out.println("Please Enter The Date For Returning The Books");
            System.out.println("Note Enter in Format :: yyyy-mm-dd");
            String re = ac.readLine();

            stmt.setString(1, id);
            stmt.setString(2, name);
            stmt.setString(3, cd);
            stmt.setString(4, re);
            stmt.setString(5, mail);
            stmt.executeUpdate();
        }

        

        

        // String selectQuery

        
        // Update the book in issue table in DB
    }
}