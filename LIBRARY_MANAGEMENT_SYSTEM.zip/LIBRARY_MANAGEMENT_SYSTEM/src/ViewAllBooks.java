package src;

import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


class ViewAllBooks {
    Profile p = new Profile();
    public void viewBooks(String url , String username , String password ,String gmail) throws Exception {
        Scanner sc = new Scanner(System.in);
        int c;
        do {
            System.out.println("*****BOOKS SECTION*****\n");
            System.out.println("1.> View All Books");
            System.out.println("2.> View from Genre and Language");
            System.out.println("3.> BACK");
            System.out.println();
            int s = sc.nextInt();
            switch (s) {
                case 1:
                    view( url ,  username ,  password);
                    break;
                case 2:
                    filter(sc ,  url ,  username ,  password);
                    break;
                case 3:
                    p.ProfileIn(url, username, password ,gmail);
                    break;
            }
            System.out.println("Type 1 to continue or 0 to not ");
            c = sc.nextInt();
        } while (c == 1);

        // match genre and language with all books and retrieve such table

    }

    public void filter(Scanner sc , String url , String username , String password) throws Exception {
        System.out.println("Enter the Genre of the Book you want");
        String gen = sc.next();

        System.out.println("Enter the Language of the Book you want");
        String lang = sc.next();

        

        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement ps = con.prepareStatement("select * from books where gener = ? and langauge = ? ");
        ps.setString(1, gen);
        ps.setString(2, lang);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String id = rs.getString("id");
            String bookname = rs.getString("book_name");
            String authorname = rs.getString("Author_name");
            String genre = rs.getString("gener");
            String language = rs.getString("langauge"); 

            System.out.println(id+" || "+bookname+"  ||  "+authorname+"  ||  "+genre+"  ||  "+language);

            System.out.println("------------------------------------------------");

        }

        // JDBC to search as per the genre and language
    }

    public void view(String url , String username , String password) throws Exception {
        System.out.println("showing all books...");
        Thread.sleep(3000);


        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement ps = con.prepareStatement("select * from books");
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            String id = rs.getString("id");
            String book_name = rs.getString("book_name");
            String Author_name = rs.getString("Author_name");
            String gener = rs.getString("gener");
            String langauge = rs.getString("langauge");

            System.out.println(id+" || "+book_name+"  ||  "+Author_name+"  ||  "+gener+"  ||  "+langauge);

            System.out.println("------------------------------------------------");
        }
        con.close();

        // view all books
    }
}
