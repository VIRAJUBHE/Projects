package src;

import java.util.*;
import java.util.Scanner;

public class MAIN {
    public void sign() throws Exception {
        
        String url = "jdbc:mysql://localhost:3306/VIRAJ";
        String username = "root";
        String password = "5463";

        
        SignUp su = new SignUp();
        SignIn si = new SignIn();
        // PassWord pi = new PassWord();
        Scanner sca = new Scanner(System.in);
        int cho;
        do {
            System.out.println("******LIBRARY MANAGEMENT SYSTEM*****");
            System.out.println("1.>  SIGN UP  ");
            System.out.println("2.>  SIGN IN  ");
            System.out.println("3.>  EXIT\n");
            cho = sca.nextInt();

            switch (cho) {
                case 1:
                    su.SignUpProfile(url , username , password);
                    break;
                case 2:
                    si.SignInProfile(url , username , password);
                    break;
                case 3:
                    break;
            }
        } while (cho != 3);
    }
}