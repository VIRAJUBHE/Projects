package src;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import  java.util.Scanner;
import java.util.Date;

class ViewProfile {
    SignIn s = new SignIn();
    Date d = new Date();
    SignUp su = new SignUp();
    public void ViewPro(String url , String username , String password , String gmail) throws Exception{

        
        Scanner sc = new Scanner(System.in);
        int ch;
        do{
            System.out.println("*****VIEW PROFILE*****\n");
                System.out.println("1. > View My Data\n");
            System.out.println("3. > BACK\n");

            ch = sc.nextInt();

            switch(ch){
                case 1:
                    System.out.println("MY DATA");
                    data(url , username , password , sc );
                    break;
                case 2:
                    break;

                }
        }while(ch == 2);
        
    }



    //-------------------------------------------------


    
    public void data(String url , String username , String password , Scanner sc )throws Exception{
        int count = 0;
        String mail =null;
        Connection con = DriverManager.getConnection(url, username, password);
        while(true){
            System.out.println("Enter your Email for Verification");
            mail = sc.next();
            
            PreparedStatement psp = con.prepareStatement("select count(*) from user where email = ?");
            psp.setString(1, mail);
            ResultSet rsr = psp.executeQuery();
            while(rsr.next()){
                count = rsr.getInt(1);
            }
            if(count > 0){
                System.out.println("\nEMAIL MATCHED\n");
                break;
            }
            else
                System.out.println("\nINVALID EMAIL");
        }




        PreparedStatement ps = con.prepareStatement("select * from user where email = ?;");
        ps.setString(1, mail);
        ResultSet rs = ps.executeQuery();
        while(rs.next()){
            int id = rs.getInt("iduser");
            String user = rs.getString("user_name");
            String email = rs.getString("email");
            //tring pass = rs.getString("password");
            String first = rs.getString("f_name");
            String last = rs.getString("l_name");
            String add = rs.getString("address");
            String phone = rs.getString("phoneno");
            System.out.println("User ID:--\t\t"+id);
            System.out.println("User Name:--\t\t"+user);
            System.out.println("First Name :--\t\t"+first);
            System.out.println("Last Name :--\t\t"+last);
            System.out.println("Phone Number:--\t\t"+phone);
            System.out.println("Address:--\t\t"+add);
            System.out.println("Email:--\t\t"+email);
            

        }

        System.out.println("\n*****MY BOOKS*****\n");

        PreparedStatement pp = con.prepareStatement("select * from issue where Email = ?;");
        pp.setString(1, mail);
        ResultSet rss= pp.executeQuery();
        while(rss.next()){
            int bookid = rss.getInt("book_id");
            String bookname = rss.getString("book_name");
            String issuedate = rss.getString("issued_date");
            String returndate = rss.getString("return_date");
            String email = rss.getString("Email");

            System.out.println(bookid+" || "+bookname+" || "+" || "+issuedate+" || "+returndate);
        }

    }
}