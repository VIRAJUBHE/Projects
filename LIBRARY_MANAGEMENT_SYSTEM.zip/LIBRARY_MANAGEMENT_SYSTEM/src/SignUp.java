package src;

import java.io.BufferedReader;
import java.io.Console;
import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class SignUp {

    public String input;

    public void SignUpProfile(String url , String username , String password) throws Exception {
        Scanner s = new Scanner(System.in);
        SignIn si = new SignIn();
        // PassWord pi = new PassWord();
        String input = "";
        Console cc;

        // JDBC
        Class.forName("com.mysql.cj.jdbc.Driver");

        

        Connection con = DriverManager.getConnection(url, username, password);
        String a = "insert into user(user_name,email,password,f_name,l_name,address,Phoneno) values(?,?,?,?,?,?,?)";
        PreparedStatement stmt = con.prepareStatement(a);

        BufferedReader ac = new BufferedReader(new InputStreamReader(System.in));

        String First = "", Last = "", email = "INVALID", Add = "" , PhNo = null;
        int c = 0;
        System.out.println("*****SIGN UP*****\n");
        System.out.println("Enter First Name ");
        First = ac.readLine();
        // insert first name in JDBC

        System.out.println("Enter Your Last Name");

        Last = ac.readLine();
        // insert last name in JDBC

        String FirLas = First + Last;
        String UserName = FirLas.toLowerCase();

        System.out.println("Press 0 to remain the Username as " + UserName + " or press 1 to create Username");

        c = s.nextInt();

        switch (c) {
            case 1:
                System.out.println("Create Username :-");

                UserName = ac.readLine();

            case 0:
                break;
            default:
        }
        Boolean isvalid;
        // insert username in JDBC
        while(true){
            System.out.println("Enter Email");

            email = ac.readLine();
            isvalid = email.matches("(.*)@gmail.com");
        
            PreparedStatement ps = con.prepareStatement("Select * from user where email = ?;");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                System.out.println("User Already Exist");
                
            } 
            else{
                System.out.println("Email Accepted");
                break;
            }
        }

        
        // insert JDBC

        System.out.println("Enter your Phone No.");
        PhNo = s.next();
        // insert JDBC

        System.out.println("Enter Your Address (PLACE)");
        Add = ac.readLine();

        char[] pad = new char[15];
        if ((cc = System.console()) != null) {
            pad = cc.readPassword("Enter The Password");
            


            System.out.println("PASSWORD ACCEPTED");
                // pi.password();

            
        } else {
            System.out.println("No Console Found");
        }
        // insert password in JDBC
        stmt.setString(1, input);
        // stmt.executeUpdate();

        stmt.setString(1, UserName);
        stmt.setString(2, email);
        stmt.setString(3,String.valueOf(pad));
        stmt.setString(4, First);
        stmt.setString(5, Last);
        stmt.setString(6, Add);
        stmt.setString(7, PhNo);
        stmt.executeUpdate();

        




        si.SignInProfile(url, username, password);
    }
}