package src;

import java.util.Scanner;

class Profile {
    public void ProfileIn(String url , String username , String password , String gmail) throws Exception {

        Scanner ac = new Scanner(System.in);
        ViewProfile vp = new ViewProfile();
        ViewAllBooks vab = new ViewAllBooks();
        AddBooks ab = new AddBooks();
        MAIN m = new MAIN();
        int button = 0;
        do {
            System.out.println("******** MAIN MENU ***********\n");
            System.out.println("1.VIEW PROFILE \n 2.ADD BOOKS \n 3.VIEW BOOKS \n 4.LOG OUT ");
            
            button = ac.nextInt();
            switch (button) {
                case 1:
                    System.out.println("VIEW PROFILE\n");
                    vp.ViewPro(url , username , password ,gmail);
                    break;
                case 2:
                    System.out.println("ADD Books \n");
                    ab.addBook(url , username , password );
                    break;
                case 3:
                    System.out.println("VIEW All BOOKS\n");   
                    vab.viewBooks( url ,  username ,  password ,gmail);
                    break;
                case 4:
                    System.out.println("LOG OUT\n");
                    m.sign();
                    break;
            }
        } while (button != 4);
        
    }
}
