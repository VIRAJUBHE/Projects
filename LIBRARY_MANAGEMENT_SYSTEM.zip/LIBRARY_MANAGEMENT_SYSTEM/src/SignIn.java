package src;

import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

class SignIn {

    
    public String gmail = null;
    

    public void SignInProfile(String url , String username , String password) throws Exception  {
        Profile p = new Profile();
        Connection con = DriverManager.getConnection(url, username, password);
        
        Scanner scanner = new Scanner(System.in);
        char[] passwordArray = new char[10];

        while(true){
            System.out.println("*****SIGN IN*****");
            System.out.println("Enter Gmail");
            gmail = scanner.next();
            Boolean isvalid = gmail.matches("(.*)@gmail.com");
            while (isvalid != true) {
                System.out.println("Please Enter Valid Email");
                gmail = scanner.next();
                isvalid = gmail.matches("(.*)@gmail.com");
            }
            PreparedStatement ps = con.prepareStatement("Select * from user where email = ?;");
            ps.setString(1, gmail);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                System.out.println("Gmail Matched");
                break;
            }
            else
                System.out.println("This input doesn't exist");
        }
        

        while(true){
            Console co = System.console();
            if (co != null) {
                passwordArray = co.readPassword("Enter your  password: ");
            } else {
                System.out.println("Password not found");
            }

            String pass = String.valueOf(passwordArray);

            PreparedStatement sp = con.prepareStatement("select * from user where password = ?;");
            sp.setString(1, pass);
            ResultSet r = sp.executeQuery();
            if(r.next()){
                System.out.println("Password Matched\n");
                break;
            }
            else
                System.out.println("This input doesn't exist");
        }

        // check password from JDBC
        p.ProfileIn( url ,  username ,  password , gmail);
    }
}
