import BankManagementSystem.*;
import java.util.Scanner;

public class Bank{
    public static void main(String[] args)throws Exception{ 
        Scanner sc = new Scanner(System.in);
        int choice = 0;

        //JDBC
        String url = "jdbc:mysql://localhost:3306/BMS";
        String username = "root";
        String password = "5463";
        Class.forName("com.mysql.cj.jdbc.Driver");

        do{
            
            System.out.println("*****WELCOME TO OUR BANK*****");
            System.out.println("1. > Bank Customer");
            System.out.println("2. > Bank Employee");
            System.out.println("3. > Bank Admin");
            System.out.println("4. > Exit\n");
            System.out.println("Enter your Choice");
            choice = sc.nextInt();

            switch(choice){

                case 1 :
                    System.out.println("Forwarding to Customer Portal . . .");
                    Thread.sleep(5000);
                    new Customer(url , username , password);
                    break;

                case 2 :
                    System.out.println("Forwarding to Employee Portal . . .");
                    Thread.sleep(5000);
                    new Employee(url , username , password);
                    break;

                case 3 :
                    System.out.println("Forwarding to Admin Portal . . .");
                    Thread.sleep(5000);
                    new Admin(url , username , password);
                    break;

            }

        }while(choice != 4);
        System.out.println("\nThank you visit again . . .");
    }
}