package BankManagementSystem;
import java.util.Scanner;
import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Employee{
    Scanner sc = new Scanner(System.in);
    public Employee(String url , String username , String password)throws Exception{
        
        int choice = 0 ;
        do{
            System.out.println("*****EMPLOYEE PORTAL*****");
            System.out.println("1. > Sign Up");
            System.out.println("2. > Sign In");
            System.out.println("3. > Exit");
            choice = sc.nextInt();

            switch(choice){

                case 1 :
                    signup(url , username , password);
                    break;
                
                case 2 :
                    signin(url , username , password);
                    break;
                
            }
        }while(choice > 3);
    }

    private void signup(String url , String username , String password)throws Exception{
        Console cc;
        

        System.out.println("\n//// SIGN IN ////\n");
        //insert fullname
        System.out.println("Enter your Full Name");
        String Fname = sc.next();

        //insert date of birth
        System.out.println("Date of Birth in the format( yyyy-mm-dd )");
        String dob = sc.next();

        //insert address
        System.out.println("Enter your Address");
        String address = sc.next();

        //insert Gender
        System.out.println("Enter your Gender");
        String gen = sc.next();

        //insert phone number
        System.out.println("Enter the Phone Number");
        String PhNo = sc.next();

        //emergency phone number
        System.out.println("Enter Emergency Contact Number");
        String EPhNo = sc.next();

        //insert email
        System.out.println("Enter Email ID");
        String email = sc.next();
        Boolean isvalid;
        isvalid = email.matches("(.*)@gmail.com");
        while(isvalid == false){
            System.out.println("Invalid Email \n Please Enter Correct Email");
            email = sc.next();
            isvalid = email.matches("(.*)gmail.com");
        }

        //education qualification
        System.out.println("Enter your Qualification");
        String edu = sc.next();

        //position
        System.out.println("Apply for which Position ? { Customer Service , Loan Officer , Financial Analyst , Risk Manager , Compliance Officer , IT Specialist , Branch Manager ,   Relationship Manager , Credit Analyst , Investment Manager}");
        String pos = sc.next();
        Connection con = DriverManager.getConnection(url , username , password);
        PreparedStatement ps = con.prepareStatement("select * from employee where Position = ?");
        ps.setString(1, pos);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            System.out.println("Sorry!! The Position has been recruited");
            System.exit(0);
        }else System.out.println("Congrats!! You have been assigned as "+pos.toUpperCase());

        //create password
        char[] pass = new char[15];
        if((cc = System.console()) != null){

            pass = cc.readPassword("Create Password");
        }
        String passwor = String.valueOf(pass);

        //insert security question
        System.out.println("Which Security Question do you prefer ?\n");
        System.out.println("1. > Who is your Childhood Friend ?");
        System.out.println("2. > What was  your Old Contact number ?");
        System.out.println("3. > Who was your Teacher in Childhood ?");
        System.out.println("Enter your choice");
        int sq = sc.nextInt();
        String answer = "" , question = "";
        switch(sq){
            case 1 :
                System.out.println("Who is your Childhood Friend ?");
                answer = sc.next();
                question = "Childhood_Friend";
                break;
            case 2:
                System.out.println("What was your Old Contact Number ?");
                answer = sc.next();
                question = "Old_Contact";
                break;
            case 3 :
                System.out.println("Who was your Teacher in Childhood ?");
                answer = sc.next();
                question = "Teacher";
                break;
        }

        PreparedStatement pp = con.prepareStatement("insert into employee (FullName , DOB , Address , Gender ,PNumber , EmerPNumber , Email , Qualification , Position , Password , SQuestion , Answer) values (? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?)");
        pp.setString(1, Fname);
        pp.setString(2, dob);
        pp.setString(3, address);
        pp.setString(4, gen);
        pp.setString(5, PhNo);
        pp.setString(6, EPhNo);
        pp.setString(7, email);
        pp.setString(8, edu);
        pp.setString(9, pos);
        pp.setString(10, passwor);
        pp.setString(11, question);
        pp.setString(12, answer);
        pp.executeUpdate();
        //show generated Employee ID

        PreparedStatement pr = con.prepareStatement("select * from employee where Email = ?");
        pr.setString(1, email);
        ResultSet rsr = pr.executeQuery();
        if(rsr.next()){
            System.out.println("\n// NOTE THIS DOWN FOR VERIFICATION //\n");
            System.out.println("Employee ID :- "+rsr.getInt("EmployeeId"));
            System.out.println("Full Name :- "+rsr.getString("FullName"));
            System.out.println("Date of Birth :- "+rsr.getString("DOB"));
            System.out.println("Address :- "+rsr.getString("Address"));
            System.out.println("Emergency Phone Number :- "+rsr.getString("EmerPNumber"));
            System.out.println("Email :- "+rsr.getString("Email"));
            System.out.println();
        }

        //jump to signin
        signin(url , username , password);

    }

    private void signin(String url , String username , String password)throws Exception{
        Console cc;

        System.out.println("\n//// SIGN IN ////\n");

        //verify employee id
        int No = 0 , EmpId;
        
        do{
            System.out.println("Enter your Employee ID");
            EmpId = sc.nextInt();

            Connection con = DriverManager.getConnection(url, username, password);
            PreparedStatement prst = con.prepareStatement("SELECT EmployeeId from employee where EmployeeId = ?");
            prst.setInt(1, EmpId);
            ResultSet rs = prst.executeQuery();
            if(rs.next()){
                No = rs.getInt("EmployeeId");
            }
            if(EmpId == No){
                break;
            }else System.out.println("\n!!!!! INVALID Employee ID !!!!!\n");
        }while(true);

        //enter password
        
        int flag ;
        do{
            System.out.println("1.> Enter Password");
            System.out.println("2.> Forget Password");
            System.out.println("\nEnter choice");
            int ch = sc.nextInt();
            flag = 0;
            Connection con = DriverManager.getConnection(url, username, password);
            switch(ch){
                case 1:
                    System.out.println("Enter Password");
                    String password2 = sc.next();
                    
                    PreparedStatement stmt = con.prepareStatement("select Password from employee where Password = ?");
                    stmt.setString(1, password2 );
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next()){
                        System.out.println("%% PASSWORD ACCEPTED %%");
                        flag = 1;
                    }
                    else System.out.println("!!!! INVALID PASSWORD !!!!");
                    break;

                case 2:
                    System.out.println("Enter Your Registered Email ID");
                    String email = sc.next();
                    

                    PreparedStatement pr = con.prepareStatement("select Email from employee where EmployeeId = ?");
                    pr.setInt(1, No);
                    ResultSet rr = pr.executeQuery();
                    
                    if(rr.next()){
                        String email1 = rr.getString("Email");
                        if(email1.equals(email)){
                            PreparedStatement pp = con.prepareStatement("select SQuestion from employee where EmployeeId = ?");
                            pp.setInt(1, No);
                            ResultSet rrr= pp.executeQuery();
                            
                            if(rrr.next()){
                                String question = rrr.getString("SQuestion");

                                //Security Question 1
                                if(question.equals("Old_Contact")){
                                    System.out.println("What was your Old Contact Number ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from employee where EmployeeId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update employee set Password = ? where EmployeeId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 2
                                else if(question.equals("Childhood_Friend") ){
                                    System.out.println("Who is your Childhood Friend ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from employee where EmployeeId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update employee set Password = ? where EmployeeId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 3
                                else if(question.equals("Teacher")){
                                    System.out.println("Who was your Teacher in Childhood ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from employee where EmployeeId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update employee set Password = ? where EmployeeId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }
                            }
                        }else System.out.println("!!!! WRONG EMAIL !!!!");
                    }
                    break;
            }
        }while(flag == 0);

        new EmployeeProfile(EmpId , url, username, password);
        //  if forgot password
        // verify above password and if wrong then ask S.question and registered email

    }
}