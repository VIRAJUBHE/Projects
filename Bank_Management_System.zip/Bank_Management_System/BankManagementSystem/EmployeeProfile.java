package BankManagementSystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class EmployeeProfile{
    Scanner sc = new Scanner(System.in);
    public EmployeeProfile(int EmpId , String url , String username , String password)throws Exception{
        int choice;
        do{
            System.out.println("\n*****Employee's Bank Portal*****\n");
            System.out.println("1.> View Profile");
            System.out.println("2.> View Customer Details");
            System.out.println("3.> View Any Customer Transactions");
            System.out.println("4.> Log Out");
            choice = sc.nextInt();

            switch(choice){
                case 1:
                    // view all data of employee
                    EmpProf(EmpId , url, username, password);
                    break;
                
                case 2 :
                    //view customer details
                    ViewCustomer(url, username, password);
                    break;

                case 3 :
                    //view any customer Transactions
                    ViewTransaction(url, username, password);
                    break;

                
            }
        }while(choice != 4);
    }

    private void EmpProf(int empid , String url , String username , String password)throws Exception{

        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement p = con.prepareStatement("select * from employee where EmployeeId = ?");
        p.setInt(1, empid);
        ResultSet r = p.executeQuery();
        if(r.next()){
            System.out.println("\n*****EMPLOYEE DETAILS*****\n");
            System.out.println("Employee ID :- "+r.getInt("EmployeeId"));
            System.out.println("Employee Name :- "+r.getString("FullName"));
            System.out.println("Address :- "+r.getString("Address"));
            System.out.println("Emergency Phone Number :- "+r.getString("EmerPNumber"));
            System.out.println("Email ID :- "+r.getString("Email"));
            System.out.println("Current Position :- "+r.getString("Position"));
            System.out.println();
        }
    }

    private void ViewCustomer(String url , String username , String password)throws Exception{

        System.out.println("Enter Account Number to view its Profile");
        int acc = sc.nextInt();
        Connection co = DriverManager.getConnection(url, username, password);
        PreparedStatement ps = co.prepareStatement("select * from customer where AccountNo = ?");
        ps.setInt(1 , acc);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            System.out.println("\n***** "+rs.getString("FullName")+"'s ACCOUNT DETAILS*****\n");
            System.out.println("Account Number :- "+rs.getInt("AccountNo"));
            System.out.println("Acount Holder's Name :- "+rs.getString("FullName"));
            System.out.println("Address :- "+rs.getString("Address"));
            System.out.println("Phone Number :- "+rs.getString("PNumber"));
            System.out.println("Email ID :- "+rs.getString("Email"));
            System.out.println("Aadhar Number :- "+rs.getString("AdharNumber"));
            System.out.println("PAN Number :- "+rs.getString("PanNumber"));
            System.out.println("Current Account Type :- "+rs.getString("AccountType"));
            System.out.println("Current Balance :- "+rs.getInt("Balance"));
            System.out.println();
        }else System.out.println("!!!! INVALID ACCOUNT NUMBER !!!!");
    }

    private void ViewTransaction(String url , String username , String password)throws Exception{

        System.out.println("Enter Account Number");
        int account = sc.nextInt();
        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement p = con.prepareStatement("select * from transaction where FromAccNo = ?");
        p.setInt(1 , account);
        ResultSet r = p.executeQuery();
        int flag = 0;
        while(r.next()){
            System.out.println("\nTransaction ID :- "+r.getInt("TransactionId"));
            System.out.println("From Account Number :- "+r.getInt("FromAccNo"));
            System.out.println("To Account Number :- "+r.getInt("ToAccNo"));
            System.out.println("Amount :- "+r.getInt("Amount"));
            System.out.println("At Time :- "+r.getString("Date")+" "+r.getString("Time"));
            System.out.println("\n***************************************");
            flag = 1;
        }
        if(flag == 0)System.out.println("!!!! No Transactions Found !!!!");
    }
}