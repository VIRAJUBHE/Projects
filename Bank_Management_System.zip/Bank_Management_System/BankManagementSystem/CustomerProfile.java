package BankManagementSystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Random;

public class CustomerProfile{
    Scanner sc = new Scanner(System.in);
    public CustomerProfile(int AccId , String url , String username , String password)throws Exception{
        int choice;
        do{
            System.out.println("\n*****Customer's Bank Portal*****\n");
            System.out.println("1.> View Account");
            System.out.println("2.> Funds Transfer");
            System.out.println("3.> Transaction History");
            System.out.println("4.> View Balance");
            System.out.println("5.> Log Out");
            choice = sc.nextInt();

            switch(choice){
                case 1:
                    // view all data of acc. holder
                    ViewAcc(AccId , url, username, password);
                    break;
                
                case 2 :
                    //transfer money to different acc. No. or cash
                    DoTransfer(AccId ,url, username, password);
                    break;

                case 3 :
                    //view Transaction History
                    ViewTransaction(AccId, url, username, password);
                    break;

                case 4 :
                    // view current balance
                    ViewBal(AccId, url, username, password);
                    break;
                
            }
        }while(choice != 5);
    }

    private void ViewAcc(int acc , String url , String username , String password)throws Exception{

        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement ps = con.prepareStatement("select * from customer where AccountNo = ?");
        ps.setInt(1 , acc);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            System.out.println("\n*****ACCOUNT DETAILS*****\n");
            System.out.println("Account Number :- "+rs.getInt("AccountNo"));
            System.out.println("Acount Holder's Name :- "+rs.getString("FullName"));
            System.out.println("Address :- "+rs.getString("Address"));
            System.out.println("Phone Number :- "+rs.getString("PNumber"));
            System.out.println("Email ID :- "+rs.getString("Email"));
            System.out.println("Current Account Type :- "+rs.getString("AccountType"));
            System.out.println();
        }
    }

    private void ViewBal(int acc , String url , String username , String password)throws Exception{

        do{
            System.out.println("Enter Password for Verification");
            String password1 = sc.next();
            Connection con = DriverManager.getConnection(url, username, password);
            PreparedStatement ps = con.prepareStatement("select Password from customer where AccountNo = ?");
            ps.setInt(1, acc);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                String pass = rs.getString("Password");
                if(password1.equals(pass))break;
                else System.out.println("Incorrect Password");
            }else System.out.println("Incorrect Password");
        }while(true);

        Connection co = DriverManager.getConnection(url, username, password);
        PreparedStatement pp = co.prepareStatement("select Balance from customer where AccountNo = ?");
        pp.setInt(1, acc);
        ResultSet rs = pp.executeQuery();
        if(rs.next()){
            System.out.println("\nCurrent Balance is\t"+rs.getInt("Balance")+"\n");
        }

    }

    private void DoTransfer(int account ,String url , String username , String password)throws Exception{

        int choice = 0;
        do{
            System.out.println("$$ Transfer Money $$");
            System.out.println("1.> Cash Transfer");
            System.out.println("2.> Online Transfer");
            System.out.println("3.> Exit");
            choice = sc.nextInt();
            switch(choice){
                case 1:
                    CashTransfer(account ,url, username, password);
                    break;
                
                case 2:
                    OnlineTransfer(account ,url, username, password);
                    break;
            }

        }while(choice > 3);

    }

    private void CashTransfer(int account , String url , String username , String password)throws Exception{

        int ch ;
        do{
            System.out.println("1.> Deposit Cash");
            System.out.println("2.> Withdraw Cash");
            ch = sc.nextInt();
            switch (ch) {
                case 1:
                    System.out.println("Enter the Amount");
                    int amo = sc.nextInt();
                    Connection con = DriverManager.getConnection(url, username, password);
                    PreparedStatement ps = con.prepareStatement("select Balance from customer where AccountNo = ?");
                    ps.setInt(1 , account);
                    ResultSet rr = ps.executeQuery();
                    if(rr.next()){
                        int balance = rr.getInt("Balance");
                        balance += amo;
                        PreparedStatement pss = con.prepareStatement("Update customer set Balance = ? where AccountNo = ?");
                        pss.setInt(1 , balance);
                        pss.setInt(2 , account);
                        pss.executeUpdate();
                        System.out.println("$$ AMOUNT HAS DEPOSITED $$");
                    }
                    
                    break;
            
                case 2:
                    System.out.println("Enter the Amount");
                    int amm = sc.nextInt();
                    Connection co = DriverManager.getConnection(url, username, password);
                    PreparedStatement sp = co.prepareStatement("select Balance from customer where AccountNo = ?");
                    sp.setInt(1, account);
                    ResultSet rs = sp.executeQuery();
                    if(rs.next()){
                        int bal = rs.getInt("Balance");
                        if(amm < bal){
                            bal -= amm;
                            PreparedStatement psp = co.prepareStatement("Update customer set Balance = ? where AccountNo = ?");
                            psp.setInt(1,bal);
                            psp.executeUpdate();
                        }else System.out.println("$$ NOT HAVING MUCH MONEY $$");
                    }else System.out.println("$$ NOT HAVING MUCH MONEY $$");
                    break;
            }
        }while(ch > 3);
    }


    private void OnlineTransfer(int acc , String url , String username , String password)throws Exception{

        System.out.println("Enter Account Number of receiver");
        int rece = sc.nextInt();
        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement ps = con.prepareStatement("select AccountNo from customer where AccountNo = ?");
        ps.setInt(1, rece);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){
            int bb = rs.getInt("AccountNo");
            if(rece == bb ){
                System.out.println("ACCEPTED");
                Transfer(acc , bb,url, username, password);
            }
            else System.out.println("Invalid Account Number");
        }else System.out.println("Invalid Account Number");
    }

    private void Transfer(int account1 ,int account2, String url , String username , String password)throws Exception{

        System.out.println("Enter the Amount");
        int bal = sc.nextInt();
        Connection coc = DriverManager.getConnection(url, username, password);
        Random ran = new Random();

        int bal1 = 0 , bal2 = 0;

        PreparedStatement ps = coc.prepareStatement("select Balance from customer where AccountNo = ?");
        ps.setInt(1, account1);
        ResultSet rs = ps.executeQuery();
        if(rs.next()){bal1 = rs.getInt("Balance");}

        PreparedStatement psp = coc.prepareStatement("select Balance from customer where AccountNo = ?");
        psp.setInt(1, account2);
        ResultSet rss = psp.executeQuery();
        if(rss.next()){bal2 = rss.getInt("Balance");}

        bal2 += bal;
        bal1 -= bal;

        PreparedStatement sp = coc.prepareStatement("select AccountType from customer where AccountNo = ?");
        sp.setInt(1, account1);
        ResultSet sr = sp.executeQuery();
        if(sr.next()){
            if((sr.getString("AccountType")).equals("Saving")){

                int saving = ran.nextInt(10 , 15);

                bal1 -= saving;
            }
            else if((sr.getString("AccountType")).equals("Current")){

                int current = ran.nextInt(10 , 15);

                bal1 -= current;
            }
        }

        PreparedStatement pp = coc.prepareStatement("Update customer set Balance = ? where AccountNo = ?");
        pp.setInt(1 , bal1);
        pp.setInt(2 , account1);
        pp.executeUpdate();

        PreparedStatement ppp = coc.prepareStatement("Update customer set Balance = ? where AccountNo = ?");
        ppp.setInt(1 , bal2);
        ppp.setInt(2 , account2);
        ppp.executeUpdate();

        LocalDate currdate = LocalDate.now();
        LocalTime currtime = LocalTime.now();
        System.out.println("Money Transfered Successfully on "+currdate+" "+currtime);
        String currda = currdate.toString();
        String currti = currtime.toString();
        PreparedStatement pssp = coc.prepareStatement("insert into transaction ( FromAccNo , ToAccNo , Amount , Date , Time) values (? , ? , ? , ? , ?)");
        pssp.setInt(1 , account1);
        pssp.setInt(2 , account2);
        pssp.setInt(3 , bal);
        pssp.setString(4 , currda);
        pssp.setString(5 , currti);
        pssp.executeUpdate();
    }

    private void ViewTransaction(int account,  String url , String username , String password)throws Exception{

        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement p = con.prepareStatement("select * from transaction where FromAccNo = ?");
        p.setInt(1 , account);
        ResultSet r = p.executeQuery();
        while(r.next()){
            System.out.println("\nTransaction ID :- "+r.getInt("TransactionId"));
            System.out.println("To Account Number :- "+r.getInt("ToAccNo"));
            System.out.println("Amount :- "+r.getInt("Amount"));
            System.out.println("At Time :- "+r.getString("Date")+" "+r.getString("Time"));
            System.out.println("\n***************************************");
        }
    }
}