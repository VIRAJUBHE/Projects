package BankManagementSystem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class AdminProfile{
    Scanner sc = new Scanner(System.in);
    public AdminProfile(int AdminId , String url , String username , String password)throws Exception{
        int choice;
        do{
            System.out.println("\n*****Admin's Bank Portal*****\n");
            System.out.println("1.> View Profile");
            System.out.println("2.> View Customer Details");
            System.out.println("3.> View Employee Details");
            System.out.println("4.> View All Transactions made by Customers");
            System.out.println("5.> Log Out");
            choice = sc.nextInt();

            switch(choice){
                case 1:
                    // view all data of admin
                    ViewProfile(AdminId, url, username, password);
                    break;
                
                case 2 :
                    //view customer details
                    //view no. of accounts opened
                    //view all accounts
                    ViewCust(url, username, password);
                    break;

                case 3 :
                    //view employee details
                    //view no. of employees
                    //view all employees details
                    //view by position
                    ViewEmp(url, username, password);
                    break;

                case 4 :
                    //view all  transactions
                    ViewTransaction(url, username, password);
                    break;
            }
        }while(choice != 5);
    }

    private void ViewProfile(int AdId , String url , String username , String password)throws Exception{
        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement p = con.prepareStatement("select * from admin where AdminId = ?");
        p.setInt(1, AdId);
        ResultSet r = p.executeQuery();
        if(r.next()){
            System.out.println("\n*****ADMIN DETAILS*****\n");
            System.out.println("Admin ID :- "+r.getInt("AdminId"));
            System.out.println("Admin Name :- "+r.getString("FullName"));
            System.out.println("Emergency Phone Number :- "+r.getString("EmerPNumber"));
            System.out.println("Email ID :- "+r.getString("Email"));
            System.out.println();
        }
    }

    private void ViewCust(String url , String username , String password)throws Exception{

        Connection con = DriverManager.getConnection(url, username, password);
        int choice;
        do{
            System.out.println("**** CUSTOMER DETAILS");
            System.out.println("1.> View No. of Accounts");
            System.out.println("2.> View all Accounts");
            System.out.println();
            System.out.println("Enter your choice");
            choice = sc.nextInt();
            switch (choice) {
                case 1:
                    PreparedStatement ps =con.prepareStatement("select count(AccountNo) from customer");
                    ResultSet rs = ps.executeQuery();
                    if(rs.next()){
                        System.out.println("\n There are "+rs.getInt("count(AccountNo)")+" accounts present in the System\n");
                    }
                    break;
            
                case 2:
                    PreparedStatement p = con.prepareStatement("select * from customer");
                    ResultSet r = p.executeQuery();
                    while(r.next()){
                        System.out.println("\n***** "+r.getString("FullName")+"'s ACCOUNT DETAILS*****\n");
                        System.out.println("Account Number :- "+r.getInt("AccountNo"));
                        System.out.println("Acount Holder's Name :- "+r.getString("FullName"));
                        System.out.println("Address :- "+r.getString("Address"));
                        System.out.println("Phone Number :- "+r.getString("PNumber"));
                        System.out.println("Email ID :- "+r.getString("Email"));
                        System.out.println("Aadhar Number :- "+r.getString("AdharNumber"));
                        System.out.println("PAN Number :- "+r.getString("PanNumber"));
                        System.out.println("Current Account Type :- "+r.getString("AccountType"));
                        System.out.println("Current Balance :- "+r.getInt("Balance"));
                        System.out.println();
                    }
                    break;
            }
        }while(choice > 3);
    }

    private void ViewEmp(String url , String username , String password)throws Exception{

        Connection co = DriverManager.getConnection(url, username, password);
        int ch;
        do{
            System.out.println("**** EMPLOYEE DETAILS ****");
            System.out.println("1.> View Number of Employees Working in the Bank");
            System.out.println("2.> View Employees Position");
            System.out.println("3.> View All Details");
            System.out.println();
            System.out.println("Enter your Choice");
            ch = sc.nextInt();

            switch(ch){
                case 1:
                    PreparedStatement ps =co.prepareStatement("select count(EmployeeId) from employee");
                    ResultSet rs = ps.executeQuery();
                    if(rs.next()){
                        System.out.println("\n There are "+rs.getInt("count(EmployeeId)")+" Employees in the Bank\n");
                    }
                    break;
                
                case 2 :
                    PreparedStatement p = co.prepareStatement("select FullName , EmerPNumber , Qualification , Position from employee;");
                    ResultSet r = p.executeQuery();
                    while(r.next()){
                        System.out.println("\n**** Employee "+r.getString("FullName")+" ****\n");
                        System.out.println("Name of Employee :- "+r.getString("FullName"));
                        System.out.println("Emergency Phone Number :- "+r.getString("EmerPNumber"));
                        System.out.println("Qualification :- "+r.getString("Qualification"));
                        System.out.println("Position in Bank :- "+r.getString("Position"));
                        System.out.println();
                    }
                    break;
                
                case 3:
                    PreparedStatement pp = co.prepareStatement("select * from employee");
                    ResultSet rr = pp.executeQuery();
                    while(rr.next()){
                        System.out.println("\n**** Employee "+rr.getString("FullName")+" ****");
                        System.out.println("Employee ID :- "+rr.getString("EmployeeId"));
                        System.out.println("Employee Name :- "+rr.getString("FullName"));
                        System.out.println("Address :- "+rr.getString("Address"));
                        System.out.println("Emergency Phone Number :- "+rr.getString("EmerPNumber"));
                        System.out.println("Qualification :- "+rr.getString("Qualification"));
                        System.out.println("Position in Bank :- "+rr.getString("Position"));
                        System.out.println();
                    }
                    break;
            }
        }while(ch > 4);
    }

    private void ViewTransaction(String url , String username , String password)throws Exception{

        Connection cc = DriverManager.getConnection(url, username, password);
        PreparedStatement ppp = cc.prepareStatement("select * from transaction");
        ResultSet rrr = ppp.executeQuery();
        int flag = 0;
        while(rrr.next()){
            System.out.println("\n***************************************");
            System.out.println("\nTransaction ID :- "+rrr.getInt("TransactionId"));
            System.out.println("From Account Number :- "+rrr.getInt("FromAccNo"));
            System.out.println("To Account Number :- "+rrr.getInt("ToAccNo"));
            System.out.println("Amount :- "+rrr.getInt("Amount"));
            System.out.println("At Time :- "+rrr.getString("Date")+" "+rrr.getString("Time"));
            
            flag = 1;
        }
        if(flag == 0)System.out.println("!!!! No Transactions Found !!!!");
    }
}