package BankManagementSystem;
import java.util.Scanner;
import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;


public class Customer{
    Scanner sc = new Scanner(System.in);
    public Customer(String url , String username , String password) throws Exception{
        
        int choice = 0 ;
        do{
            System.out.println("*****CUSTOMER PORTAL*****");
            System.out.println("1. > Sign Up");
            System.out.println("2. > Sign In");
            System.out.println("3. > Exit");
            choice = sc.nextInt();

            switch(choice){

                case 1 :
                    signup(url , username , password);
                    break;
                
                case 2 :
                    signin(url , username , password);
                    break;
                
            }
        }while(choice > 3);
    }

    private void signup(String url , String username , String password) throws Exception{
        Console cc;
        System.out.println("\n//// SIGN UP ////\n");

        //insert fullname
        System.out.println("Enter your Full Name");
        String Fname = sc.next();

        //insert date of birth
        System.out.println("Date of Birth in the format( yyyy-mm-dd )");
        String dob = sc.next();

        //insert address
        System.out.println("Enter your Address");
        String address = sc.next();

        //insert phone number
        System.out.println("Enter the Phone Number");
        String PhNo = sc.next();

        //insert email
        System.out.println("Enter Email ID");
        String email = sc.next();
        Boolean isvalid;
        isvalid = email.matches("(.*)@gmail.com");
        while(isvalid == false){
            System.out.println("Invalid Email \n Please Enter Correct Email");
            email = sc.next();
            isvalid = email.matches("(.*)gmail.com");
        }

        //insert aadhar number
        System.out.println("Enter Registered Aadhar Card Number");
        String adhar = sc.next();
        
        //insert pan number
        System.out.println("Enter PAN Number");
        String pan = sc.next();
        

        //account type
        int ch;
        String acctype = "";
        do{
            System.out.println("In SAVING account , the least amount shoukd be of Rs. 500 and after each Successfull Transaction Rs.10 to Rs.15 will be cut as per the interest\nIn Current account , the least amount should be of Rs.2000 and after each Successfull Transaction Rs.1 to Rs.5 will be cut as per the interest\n");
            System.out.println("Type of Account ( Type (0) for saving account / Type (1) for current account )");
            ch = sc.nextInt();
            
        
            switch(ch){
                case 0 :
                    acctype = "Saving";
                    break;
                case 1 :
                    acctype = "Current";
                    break;

            }
        }while(ch > 2);

        //create password
        char[] pass = new char[15];
        if((cc = System.console()) != null){

            pass = cc.readPassword("Create Password");
        }else{
            System.out.println("Invalid");
        }
        String passwor = String.valueOf(pass);

        //insert security question
        System.out.println("Which Security Question do you prefer ?\n");
        System.out.println("1. > Who is your Childhood Friend ?");
        System.out.println("2. > What was  your Old Contact number ?");
        System.out.println("3. > Who was your Teacher in Childhood ?");
        System.out.println("Enter your choice");
        int sq = sc.nextInt();
        String answer = "" , question = "";
        switch(sq){
            case 1 :
                System.out.println("Who is your Childhood Friend ?");
                answer = sc.next();
                question = "Childhood_Friend";
                break;
            case 2:
                System.out.println("What was your Old Contact Number ?");
                answer = sc.next();
                question = "Old_Contact";
                break;
            case 3 :
                System.out.println("Who was your Teacher in Childhood ?");
                answer = sc.next();
                question = "Teacher";
                break;
        }

        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement prst = con.prepareStatement("insert into customer ( FullName , DOB , Address , PNumber , Email , AdharNumber , PanNumber , AccountType , Password , SQuestion , Answer , Balance) values ( ? , ? , ? , ? , ? , ? , ? , ? , ? , ? , ?  , ?)");

        prst.setString(1, Fname);
        prst.setString(2, dob);
        prst.setString(3, address);
        prst.setString(4, PhNo);
        prst.setString(5, email);
        prst.setString(6, adhar);
        prst.setString(7, pan.toUpperCase());
        prst.setString(8, acctype);
        prst.setString(9, passwor);
        prst.setString(10, question);
        prst.setString(11, answer);

        if(acctype == "Saving") prst.setInt(12 , 2000);
        else if(acctype == "Current") prst.setInt(12 , 500); 
        prst.executeUpdate();

        //show generated account number
        PreparedStatement pr = con.prepareStatement("select * from customer where Email = ?");
        pr.setString(1, email);
        ResultSet rs = pr.executeQuery();
        if(rs.next()){
            System.out.println("\n// NOTE THIS DOWN FOR VERIFICATION //\n");
            System.out.println("Account Number :- "+rs.getInt("AccountNo"));
            System.out.println("Full Name :- "+rs.getString("FullName"));
            System.out.println("Date of Birth :- "+rs.getString("DOB"));
            System.out.println("Address :- "+rs.getString("Address"));
            System.out.println("Phone Number :- "+rs.getString("PNumber"));
            System.out.println("Email :- "+rs.getString("Email"));
            System.out.println("Account Type :- "+rs.getString("AccountType"));
            System.out.println("Remaining Balance :- "+rs.getInt("Balance"));
            System.out.println();
        }

        //jump to signin
        signin(url ,username ,password);
    }

    

    private void signin(String url , String username , String password)throws Exception{
        
        Console cc;
        int No = 0 , accNo;
        //verify accNo with DB
        System.out.println("\n//// SIGN IN ////\n");
        do{
            System.out.println("Enter your Account Number");
            accNo = sc.nextInt();

            Connection con = DriverManager.getConnection(url, username, password);
            PreparedStatement prst = con.prepareStatement("SELECT AccountNo from customer where AccountNo = ?");
            prst.setInt(1, accNo);
            ResultSet rs = prst.executeQuery();
            if(rs.next()){
                No = rs.getInt("AccountNo");
            }
            if(accNo == No){
                break;
            }else System.out.println("\n!!!!! INVALID ACCOUNT NUMBER !!!!!\n");
        }while(true);

        //password verification
        //  if forgot password
        // verify above password and if wrong then ask S.question and registered email
        
        int flag ;
        do{
            System.out.println("1.> Enter Password");
            System.out.println("2.> Forget Password");
            System.out.println("\nEnter choice");
            int ch = sc.nextInt();
            flag = 0;
            Connection con = DriverManager.getConnection(url, username, password);
            switch(ch){
                case 1:
                    System.out.println("Enter Password");
                    String password2 = sc.next();
                    
                    PreparedStatement stmt = con.prepareStatement("select Password from customer where Password = ?");
                    stmt.setString(1, password2 );
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next()){
                        System.out.println("%% PASSWORD ACCEPTED %%");
                        flag = 1;
                    }
                    else System.out.println("!!!! INVALID PASSWORD !!!!");
                    break;

                case 2:
                    System.out.println("Enter Your Registered Email ID");
                    String email = sc.next();
                    

                    PreparedStatement pr = con.prepareStatement("select Email from customer where AccountNo = ?");
                    pr.setInt(1, No);
                    ResultSet rr = pr.executeQuery();
                    
                    if(rr.next()){
                        String email1 = rr.getString("Email");
                        if(email1.equals(email)){
                            PreparedStatement pp = con.prepareStatement("select SQuestion from customer where AccountNo = ?");
                            pp.setInt(1, No);
                            ResultSet rrr= pp.executeQuery();
                            
                            if(rrr.next()){
                                String question = rrr.getString("SQuestion");

                                //Security Question 1
                                if(question.equals("Old_Contact")){
                                    System.out.println("What was your Old Contact Number ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from customer where AccountNo = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update customer set Password = ? where AccountNo = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 2
                                else if(question.equals("Childhood_Friend") ){
                                    System.out.println("Who is your Childhood Friend ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from customer where AccountNo = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update customer set Password = ? where AccountNo = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 3
                                else if(question.equals("Teacher")){
                                    System.out.println("Who was your Teacher in Childhood ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from customer where AccountNo = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update customer set Password = ? where AccountNo = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }
                            }
                        }else System.out.println("!!!! WRONG EMAIL !!!!");
                    }
                    break;
            }
        }while(flag == 0);
        

        
        //  if forgot password
        // verify above password and if wrong then ask S.question and registered email

        int acc = accNo;
        new CustomerProfile(acc ,  url ,  username ,  password);

    }
}