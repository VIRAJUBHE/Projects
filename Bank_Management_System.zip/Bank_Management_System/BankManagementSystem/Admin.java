package BankManagementSystem;
import java.util.Scanner;
import java.io.Console;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Admin{
    Scanner sc = new Scanner(System.in);
    public Admin(String url , String username , String password)throws Exception{
        
        int choice = 0 ;
        do{
            System.out.println("*****ADMIN PORTAL*****");
            System.out.println("1. > Sign Up");
            System.out.println("2. > Sign In");
            System.out.println("3. > Exit");
            choice = sc.nextInt();

            switch(choice){

                case 1 :
                    signup(url , username , password);
                    break;
                
                case 2 :
                    signin(url , username , password);
                    break;
                
            }
        }while(choice > 3);
    }

    private void signup(String url , String username , String password)throws Exception{
        Console cc;

        System.out.println("\n//// SIGN UP ////\n");
        //insert fullname
        System.out.println("Enter your Full Name");
        String Fname = sc.next();

        //insert age but admin should be from 30 to 40
        System.out.println("Enter your Age");
        int dob = sc.nextInt();
        int flag = 0;
        if(dob >= 30 && dob <= 40)flag = 1;
        while(flag == 0){
            System.out.println("Age should be from 30 to 40");
            dob = sc.nextInt();
            if(dob >= 30 && dob <= 40)flag = 1;
        }

        //insert Gender
        System.out.println("Enter your Gender");
        String gen = sc.next();

        //insert phone number
        System.out.println("Enter the Phone Number");
        String PhNo = sc.next();

        //insert phone number
        System.out.println("Enter the Emergency Phone Number");
        String EPhNo = sc.next();

        //insert email
        System.out.println("Enter Email ID");
        String email = sc.next();
        Boolean isvalid;
        isvalid = email.matches("(.*)@gmail.com");
        while(isvalid == false){
            System.out.println("Invalid Email \n Please Enter Correct Email");
            email = sc.next();
            isvalid = email.matches("(.*)gmail.com");
        }

        //create password
        char[] pass = new char[15];
        if((cc = System.console()) != null){

            pass = cc.readPassword("Create Password");
        }
        String passwo = String.valueOf(pass);

        //insert security question
        System.out.println("Which Security Question do you prefer ?\n");
        System.out.println("1. > Who is your Childhood Friend ?");
        System.out.println("2. > What was  your Old Contact number ?");
        System.out.println("3. > Who was your Teacher in Childhood ?");
        System.out.println("Enter your choice");
        int sq = sc.nextInt();
        String answer = "" , question = "";
        switch(sq){
            case 1 :
                System.out.println("Who is your Childhood Friend ?");
                answer = sc.next();
                question = "Childhood_Friend";
                break;
            case 2:
                System.out.println("What was your Old Contact Number ?");
                answer = sc.next();
                question = "Old_Contact";
                break;
            case 3 :
                System.out.println("Who was your Teacher in Childhood ?");
                answer = sc.next();
                question = "Teacher";
                break;
        }

        
        Connection con = DriverManager.getConnection(url, username, password);
        PreparedStatement pp = con.prepareStatement("insert into admin values (? , ? , ? , ? , ? , ? , ? , ? , ?)");
        pp.setString(1, Fname);
        pp.setString(2, gen);
        pp.setInt(3, dob);
        pp.setString(4, PhNo);
        pp.setString(5, EPhNo);
        pp.setString(6, email);
        pp.setString(7, passwo);
        pp.setString(8, question);
        pp.setString(9, answer);
        pp.executeUpdate();
        
        PreparedStatement pr = con.prepareStatement("select * from admin where Email = ?");
        pr.setString(1, email);
        ResultSet rsr = pr.executeQuery();
        if(rsr.next()){
            System.out.println("\n// NOTE THIS DOWN FOR VERIFICATION //\n");
            System.out.println("Admin ID :- "+rsr.getInt("AdminId"));
            System.out.println("Full Name :- "+rsr.getString("FullName"));
            System.out.println("Emergency Phone Number :- "+rsr.getString("EmerPNumber"));
            System.out.println("Email :- "+rsr.getString("Email"));
            System.out.println();
        }

        //show generated Admin ID

        //jump to signin
        signin( url ,  username ,  password);

    }

    private void signin(String url , String username , String password)throws Exception{
        
        Console cc;
        System.out.println("\n//// SIGN IN ////\n");

        //verify employee id
        int No = 0 , AdId;
        
        do{
            System.out.println("Enter your Admin ID");
            AdId = sc.nextInt();

            Connection con = DriverManager.getConnection(url, username, password);
            PreparedStatement prst = con.prepareStatement("SELECT AdminId from admin where AdminId = ?");
            prst.setInt(1, AdId);
            ResultSet rs = prst.executeQuery();
            if(rs.next()){
                No = rs.getInt("AdminId");
            }
            if(AdId == No){
                break;
            }else System.out.println("\n!!!!! INVALID Admin ID !!!!!\n");
        }while(true);

        //enter password
        
        int flag ;
        do{
            System.out.println("1.> Enter Password");
            System.out.println("2.> Forget Password");
            System.out.println("\nEnter choice");
            int ch = sc.nextInt();
            flag = 0;
            Connection con = DriverManager.getConnection(url, username, password);
            switch(ch){
                case 1:
                    System.out.println("Enter Password");
                    String password2 = sc.next();
                    
                    PreparedStatement stmt = con.prepareStatement("select Password from admin where Password = ?");
                    stmt.setString(1, password2 );
                    ResultSet rs = stmt.executeQuery();
                    if(rs.next()){
                        System.out.println("%% PASSWORD ACCEPTED %%");
                        flag = 1;
                    }
                    else System.out.println("!!!! INVALID PASSWORD !!!!");
                    break;

                case 2:
                    System.out.println("Enter Your Registered Email ID");
                    String email = sc.next();
                    

                    PreparedStatement pr = con.prepareStatement("select Email from admin where AdminId = ?");
                    pr.setInt(1, No);
                    ResultSet rr = pr.executeQuery();
                    
                    if(rr.next()){
                        String email1 = rr.getString("Email");
                        if(email1.equals(email)){
                            PreparedStatement pp = con.prepareStatement("select SQuestion from admin where AdminId = ?");
                            pp.setInt(1, No);
                            ResultSet rrr= pp.executeQuery();
                            
                            if(rrr.next()){
                                String question = rrr.getString("SQuestion");

                                //Security Question 1
                                if(question.equals("Old_Contact")){
                                    System.out.println("What was your Old Contact Number ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from admin where AdminId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update admin set Password = ? where AdminId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 2
                                else if(question.equals("Childhood_Friend") ){
                                    System.out.println("Who is your Childhood Friend ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from admin where AdminId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update admin set Password = ? where AdminId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }

                                //Security Question 3
                                else if(question.equals("Teacher")){
                                    System.out.println("Who was your Teacher in Childhood ?");
                                    String ans = sc.next();
                                    PreparedStatement prep = con.prepareStatement("select Answer from admin where AdminId = ?");
                                    prep.setInt(1 , No);
                                    ResultSet res = prep.executeQuery();
                                    String answer = "";
                                    if(res.next()) answer = res.getString("Answer");
                                    if(answer.equals(ans)){
                                        char[] pass11 = new char[15];
                                        if((cc = System.console()) != null){
                                        
                                            pass11 = cc.readPassword("Create Password");
                                        }else{
                                            System.out.println("Invalid");
                                        }
                                        System.out.println("Password Updated\n");
                                        String passwor = String.valueOf(pass11);
                                        PreparedStatement psp = con.prepareStatement("Update admin set Password = ? where AdminId = ?");
                                        psp.setString(1, passwor);
                                        psp.setInt(2, No);
                                        psp.executeUpdate();
                                        flag = 1;
                                    }else System.out.println("Answer doesn't match");
                                }
                            }
                        }else System.out.println("!!!! WRONG EMAIL !!!!");
                    }
                    break;
            }
        }while(flag == 0);

        new AdminProfile(AdId , url , username , password);
        //  if forgot password
        // verify above password and if wrong then ask S.question and registered email


    }
}